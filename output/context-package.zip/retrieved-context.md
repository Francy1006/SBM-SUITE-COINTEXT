# Retrieved Context

## SBM-SUITE/dp-api/context/PROJECT_CONTEXT.md

- source_path: `/suite/DP-API/context/PROJECT_CONTEXT.md`
- archive_path: `SBM-SUITE/dp-api/context/PROJECT_CONTEXT.md`

### Context deployment and upgrade workflow

Score: 0.890817

## Context deployment and upgrade workflow

DP-API provides:

```text
scripts/context-deploy.sh
scripts/context-upgrade.sh
```

Export:

```text
Git working tree
→ context-deploy.sh
→ change summary, changed files and diff
→ POST /contexts/export
→ Qdrant sbm_contexts
→ RAG-selected chunks
→ complete update-authorized files
→ context-package.zip
```

Upgrade:

```text
context-upgrade.zip
→ SBM-SUITE/context/input
→ context-upgrade.sh
→ POST /contexts/upgrade
→ validation
→ timestamped backup
→ a

## SBM-SUITE/dp-api/context/DEPLOY_CONTEXT.md

- source_path: `/suite/DP-API/context/DEPLOY_CONTEXT.md`
- archive_path: `SBM-SUITE/dp-api/context/DEPLOY_CONTEXT.md`

### 17. Script requirements

Score: 0.887742

## 17. Script requirements

Create:

```text
DP-API/scripts/context-deploy.sh
```

It must:

1. use `set -euo pipefail`;
2. resolve paths safely;
3. set `project_name=dp-api`;
4. clean working folders;
5. call SBM-AI-ASSISTANT;
6. wait for export completion;
7. parameterize `SYS_PROMPT.md`;
8. verify ZIP and prompt outputs;
9. print exact output paths;
10. fail immediately on error.

It must not:

- execute QA;
- execute migrations;
- modify PostgreSQL;
- update contexts directly;
- commit or pu

### 8. System prompt

Score: 0.882207

## 8. System prompt

Template:

```text
SBM-SUITE/context/SYS_PROMPT.md
```

Generated copy:

```text
SBM-SUITE/context/output/SYS_PROMPT.md
```

Replace its project parameter with:

```text
project_name=dp-api
```

The generated prompt must instruct ChatGPT to:

1. correlate DP-API with `SUITE_CONTEXT.md` and `BUSINESS_CONTEXT.md`;
2. inspect global and DP-API QA contexts without modifying them;
3. use previously completed QA evidence;
4. update DP-API and SBM-SUITE README files;
5. update both

### 21. Stable rules

Score: 0.874530

## 21. Stable rules

1. Command: `./scripts/context-deploy.sh`.
2. Project: `dp-api`.
3. SBM-AI-ASSISTANT owns embeddings and ingestion.
4. Qdrant collection: `sbm_contexts`.
5. Confluence remains in `sbm_docs`.
6. ChatGPT receives Markdown, not raw vectors.
7. Preserve paths and filenames.
8. Clean prior artifacts first.
9. Update only Project Context, Suite Context, and README files.
10. Never update QA Context in this workflow.
11. Never update Business Context automatically.
12. Never update

### 1. Scope

Score: 0.874501

## 1. Scope

`context-deploy` does not deploy application infrastructure.

It updates only:

```text
DP-API/context/PROJECT_CONTEXT.md
DP-API/README.md
SBM-SUITE/PROJECT_CONTEXT.md
SBM-SUITE/context/SUITE_CONTEXT.md
SBM-SUITE/README.md
```

It must not update:

```text
QA_CONTEXT.md
BUSINESS_CONTEXT.md
DEPLOY_CONTEXT.md
SYS_PROMPT.md
```

QA context updates belong to a future `qa-context-update` workflow.

### 5. SBM-AI-ASSISTANT responsibilities

Score: 0.868946

## 5. SBM-AI-ASSISTANT responsibilities

`context-deploy.sh` calls an SBM-AI-ASSISTANT FastAPI endpoint or function.

SBM-AI-ASSISTANT must:

1. discover applicable global and DP-API contexts;
2. read Markdown sources;
3. chunk and embed them;
4. index them in Qdrant;
5. create the ChatGPT input package;
6. copy and parameterize `SYS_PROMPT.md`.

Collections:

```text
sbm_contexts → suite and project contexts
sbm_docs     → Confluence documentation
```

Do not mix them.

Git Markdown files remai

### 2. Trigger

Score: 0.867994

## 2. Trigger

After manually completing QA, the user executes:

```bash
./scripts/context-deploy.sh
```

The script must send:

```text
project_name=dp-api
workflow=context-deploy
```

## SBM-SUITE/context/PROJECT_CONTEXT.md

- source_path: `/suite/context/PROJECT_CONTEXT.md`
- archive_path: `SBM-SUITE/context/PROJECT_CONTEXT.md`

### 8. Current context export endpoint

Score: 0.883021

SBM-SUITE/README.md
SBM-SUITE/context/SUITE_CONTEXT.md
SBM-SUITE/context/BUSINESS_CONTEXT.md
SBM-SUITE/context/QA_CONTEXT.md
SBM-SUITE/context/SYS_PROMPT.md
SBM-SUITE/dp-api/README.md
SBM-SUITE/dp-api/context/PROJECT_CONTEXT.md
SBM-SUITE/dp-api/context/QA_CONTEXT.md
SBM-SUITE/dp-api/context/DEPLOY_CONTEXT.md
```

This file restores:

```text
/suite/context/PROJECT_CONTEXT.md
```

### 7. Context deployment and upgrade workflow

Score: 0.877346

ip and parameterized SYS_PROMPT.md
→ user uploads both to ChatGPT
```

Upgrade flow:

```text
ChatGPT
→ context-upgrade.zip
→ SBM-SUITE/context/input
→ context-upgrade.sh
→ POST /contexts/upgrade
→ validate manifest, paths and SHA-256 hashes
→ create timestamped backup
→ atomically replace only authorized files
→ remove input ZIP only after complete success
```

Update-authorized files:

```text
SBM-SUITE/PROJECT_CONTEXT.md
SBM-SUITE/README.md
SBM-SUITE/context/SUITE_CONTEXT.md
SBM-SUITE/dp-api/

### 7. Context deployment and upgrade workflow

Score: 0.874540

## 7. Context deployment and upgrade workflow

Project scripts:

```text
scripts/context-deploy.sh
scripts/context-upgrade.sh
```

Export flow:

```text
Git working-tree evidence
→ context-deploy.sh
→ POST /contexts/export
→ index allowed contexts in Qdrant sbm_contexts
→ retrieve relevant global and project chunks through RAG
→ include complete update-authorized files
→ generate context-package.zip and parameterized SYS_PROMPT.md
→ user uploads both to ChatGPT
```

Upgrade flow:

```text
ChatGP

### 12. Pending

Score: 0.872179

## 12. Pending

1. Restore this file at:
   ```text
   SBM-SUITE/context/PROJECT_CONTEXT.md
   ```
2. Re-run:
   ```bash
   DP-API/scripts/context-deploy.sh
   ```
3. Confirm:
   ```text
   HTTP 200
   indexed_source_count = 10
   errors = []
   ```
4. Upload generated ZIP and `SYS_PROMPT.md` to ChatGPT.
5. Implement reviewed ZIP import later.
6. Create `qa-context-update`.
7. Add Notion synchronization and roadmap automation.
8. Create contexts for remaining projects.

### 11. Completed

Score: 0.870431

## 11. Completed

- global context structure defined;
- `SUITE_CONTEXT.md` created;
- `BUSINESS_CONTEXT.md` created;
- global `QA_CONTEXT.md` created;
- `SYS_PROMPT.md` created;
- DP-API contexts created;
- DP-API `context-deploy.sh` created;
- `POST /contexts/export` implemented;
- `sbm_contexts` implemented;
- deterministic and idempotent indexing implemented;
- context ZIP and manifest generation implemented;
- embedding performance issue corrected;
- source/archive path separation corrected;

### 8. Current context export endpoint

Score: 0.868167

ZIP creation;
- manifest generation;
- RAG retrieval from `sbm_contexts`;
- separate global and project retrieval scopes;
- export of relevant chunks through `retrieved-context.md`;
- inclusion of complete update-authorized files;
- Git change evidence in the package;
- no raw vectors exported;
- no secrets or `.env` files included.

Expected DP-API sources:

```text
SBM-SUITE/PROJECT_CONTEXT.md
SBM-SUITE/README.md
SBM-SUITE/context/SUITE_CONTEXT.md
SBM-SUITE/context/BUSINESS_CONTEXT.md
SBM-SUI

## SBM-SUITE/context/SUITE_CONTEXT.md

- source_path: `/suite/context/SUITE_CONTEXT.md`
- archive_path: `SBM-SUITE/context/SUITE_CONTEXT.md`

### 2. Context hierarchy

Score: 0.882972

└── deploy_context.md
├── SBM-MANAGER/
│   └── context/
│       ├── project_context.md
│       ├── qa_context.md
│       └── deploy_context.md
├── SBM-DB/
│   └── context/
│       ├── project_context.md
│       ├── qa_context.md
│       └── deploy_context.md
└── SBM-AI-ASSISTANT/
    └── context/
        ├── project_context.md
        ├── qa_context.md
        └── deploy_context.md
```

Context responsibility:

```text
SBM-SUITE/project_context.md
→ current global project status and active cross

### 2. Context hierarchy

Score: 0.866310

## 2. Context hierarchy

The global context structure is:

```text
SBM-SUITE/
├── project_context.md
├── context/
│   ├── suite_context.md
│   ├── business_context.md
│   └── qa_context.md
├── DP-API/
│   └── context/
│       ├── project_context.md
│       ├── qa_context.md
│       └── deploy_context.md
├── SBM-API/
│   └── context/
│       ├── project_context.md
│       ├── qa_context.md
│       └── deploy_context.md
├── SBM-MANAGER/
│   └── context/
│       ├── project_context.md
│       ├── q

## SBM-SUITE/dp-api/README.md

- source_path: `/suite/DP-API/README.md`
- archive_path: `SBM-SUITE/dp-api/README.md`

### Context lifecycle

Score: 0.880472

## Context lifecycle

Export the current project change:

```bash
./scripts/context-deploy.sh
```

Generated artifacts:

```text
SBM-SUITE/context/output/context-package.zip
SBM-SUITE/context/output/SYS_PROMPT.md
```

After ChatGPT generates `context-upgrade.zip`, place it at:

```text
SBM-SUITE/context/input/context-upgrade.zip
```

Apply the reviewed update:

```bash
./scripts/context-upgrade.sh
```

The upgrade validates paths, manifest metadata and hashes, creates a
timestamped backup, appli
