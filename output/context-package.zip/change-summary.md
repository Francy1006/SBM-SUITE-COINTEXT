Current dp-api changes affect: scripts/context-deploy.sh, scripts/context-upgrade.sh.
